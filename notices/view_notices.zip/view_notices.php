<?php  
include("../config/db_connect.php");  
session_start();  

// 🟡 Handle Date Filtering
$dateFilter = isset($_GET['filter_date']) ? $_GET['filter_date'] : '';
$query = "SELECT * FROM notices WHERE status = 'active'";

if ($dateFilter) {
    $query .= " AND DATE(uploaded_at) = '$dateFilter'";
}

$query .= " ORDER BY uploaded_at DESC";
$result = mysqli_query($conn, $query);
?>
<?php include("../header.php"); ?>

<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>📢 View Notices</title>  
    <link rel="stylesheet" href="../css/notice_styles.css">
    <script defer src="../js/notice_script.js"></script>
</head>  
<body>  

<h1>📢 Notices</h1>  

<!-- 🔽 Filter Toggle Button -->
<button id="filter-toggle">🔽 Show Filters</button>

<!-- 📌 Hidden Filter Section -->
<div class="filter-section" id="filter-section">
    <form method="GET">
        <label for="filter_date">Filter by Date:</label>
        <input type="date" name="filter_date" value="<?php echo isset($_GET['filter_date']) ? $_GET['filter_date'] : ''; ?>">
        <button type="submit">Apply Filter</button>
    </form>
</div>

<!-- 📄 Notice Table -->
<table>
    <tr>
        <th>Title</th>
        <th>Date</th>
        <th>Size</th>
        <th>Download</th>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'teacher') { ?>
            <th>Actions</th>
        <?php } ?>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?php echo $row['title']; ?></td>
        <td><?php echo date('d M Y', strtotime($row['uploaded_at'])); ?></td>
        <td><?php echo round($row['file_size'] / 1024, 2) . " KB"; ?></td>
        <td><a href="../<?php echo $row['file_path']; ?>" download>📥 Download</a></td>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'teacher') { ?>
            <td class="actions">
                <a href="delete_notice.php?id=<?php echo $row['id']; ?>" class="delete">🗑 Delete</a>
            </td>
        <?php } ?>
    </tr>
    <?php } ?>
</table>

<!-- 🔄 Show Manage Deleted Notices Button for Teachers -->
<?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'teacher') { ?>
    <p><a href="manage_notices.php" class="btn">🗑 Manage Deleted Notices</a></p>
    <p><a href="add_notice.php" class="btn">➕ Add Notice</a></p>
<?php } ?>

</body>  
</html>
